//! 透明遮罩窗口 — 延迟转发方案（Windows 专用）。
//!
//! 窗口拦截鼠标（不用 WS_EX_TRANSPARENT）：
//! - 左键第一次点击 → 延迟 300ms，期间收到第二次 → 双击 emit，否则转发单击
//! - 右键 → 立即转发
//! 转发方式：临时隐藏窗口 + mouse_event 模拟点击 + Sleep(50) + 恢复窗口
//! 窗口被销毁时自动重建，500ms 定时刷新 topmost。

#![cfg(windows)]

use std::{
    cell::RefCell,
    ptr,
    sync::{atomic::{AtomicBool, Ordering}, Mutex},
    time::{Duration, Instant},
};

use tauri::{AppHandle, Emitter};
use windows::{
    core::*,
    Win32::Foundation::*,
    Win32::Graphics::Gdi::*,
    Win32::System::LibraryLoader::GetModuleHandleW,
    Win32::System::Threading::{GetCurrentThreadId, Sleep},
    Win32::UI::Input::KeyboardAndMouse::{
        mouse_event, MOUSE_EVENT_FLAGS, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,
        MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP,
    },
    Win32::UI::WindowsAndMessaging::*,
};

// ── 常量 ───────────────────────────────────────────────────────────────────

const OVERLAY_WIDTH: i32 = 120;
const OVERLAY_HEIGHT: i32 = 48;
const SHOW_DESKTOP_GAP: i32 = 16;
const DOUBLE_CLICK_MS: u64 = 300;
const DOUBLE_CLICK_PX: i32 = 4;
const OVERLAY_COLOR: COLORREF = COLORREF(0x0000_00FF);
const TIMER_TOPMOST: usize = 1;
const TIMER_FORWARD: usize = 2;
const TIMER_INTERVAL: u32 = 500;
const FORWARD_DELAY: u32 = 300; // ms

// ── Thread local ──────────────────────────────────────────────────────────

struct ClickInfo { last_time: Option<Instant>, last_x: i32, last_y: i32 }
impl ClickInfo {
    const fn new() -> Self { Self { last_time: None, last_x: 0, last_y: 0 } }
}
thread_local! { static CLICK_INFO: RefCell<ClickInfo> = RefCell::new(ClickInfo::new()); }

/// 待转发的左键单击屏幕坐标
struct PendingClick { x: i32, y: i32 }
thread_local! { static PENDING: RefCell<Option<PendingClick>> = RefCell::new(None); }

// ── Global state ──────────────────────────────────────────────────────────

static APP_HANDLE: Mutex<Option<AppHandle>> = Mutex::new(None);

#[derive(Clone, Copy)]
#[repr(transparent)]
struct SendHWND(HWND);
unsafe impl Send for SendHWND {}
unsafe impl Sync for SendHWND {}

static OVERLAY_HWND: Mutex<Option<SendHWND>> = Mutex::new(None);
static OVERLAY_THREAD_ID: Mutex<Option<u32>> = Mutex::new(None);
static G_HINST: Mutex<Option<usize>> = Mutex::new(None);
static SHOULD_STOP: AtomicBool = AtomicBool::new(false);

fn set_app_handle(h: AppHandle) { *APP_HANDLE.lock().unwrap() = Some(h); }
fn emit_event(event: &str) {
    log(&format!("emit_event: {}", event));
    if let Some(h) = APP_HANDLE.lock().unwrap().as_ref() {
        let _ = h.emit(event, ());
    }
}

/// 文件日志 — 写入 exe 同目录的 overlay.log
fn log(msg: &str) {
    use std::io::Write;
    let exe = std::env::current_exe().unwrap_or_default();
    let dir = exe.parent().unwrap_or(std::path::Path::new("."));
    let path = dir.join("overlay.log");
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(&path) {
        let _ = writeln!(f, "{}", msg);
    }
    eprintln!("[overlay] {}", msg);
}

// ── Helpers ───────────────────────────────────────────────────────────────

fn to_wstr(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}
fn null_hwnd() -> HWND { HWND(ptr::null_mut()) }
fn null_hmenu() -> HMENU { HMENU(ptr::null_mut()) }
fn null_hmodule() -> HMODULE { HMODULE(ptr::null_mut()) }
fn hinst_from_hmodule(m: HMODULE) -> HINSTANCE { HINSTANCE(m.0 as *mut _) }

fn overlay_rect() -> (i32, i32, i32, i32) {
    let w = unsafe { GetSystemMetrics(SM_CXSCREEN) };
    let h = unsafe { GetSystemMetrics(SM_CYSCREEN) };
    let x = w - OVERLAY_WIDTH - SHOW_DESKTOP_GAP;
    let y = h - OVERLAY_HEIGHT;
    (x, y, OVERLAY_WIDTH, OVERLAY_HEIGHT)
}

fn register_class(hinst: HMODULE, class_name_w: &[u16]) {
    let cls = PCWSTR(class_name_w.as_ptr());
    let hi = hinst_from_hmodule(hinst);
    let mut dummy: WNDCLASSEXW = unsafe { std::mem::zeroed() };
    if unsafe { GetClassInfoExW(Some(hi), cls, &mut dummy) }.is_ok() { return; }
    let wc = WNDCLASSEXW {
        cbSize: std::mem::size_of::<WNDCLASSEXW>() as u32,
        style: CS_HREDRAW | CS_VREDRAW,
        lpfnWndProc: Some(wnd_proc),
        hInstance: hi,
        hCursor: unsafe { LoadCursorW(Some(hinst_from_hmodule(null_hmodule())), IDC_ARROW) }.unwrap_or_default(),
        hbrBackground: unsafe { CreateSolidBrush(OVERLAY_COLOR) },
        lpszClassName: cls,
        ..Default::default()
    };
    let _ = unsafe { RegisterClassExW(&wc) };
}

fn create_overlay_window(hinst: HMODULE, class_name_w: &[u16]) -> Option<HWND> {
    let (x, y, w, h) = overlay_rect();
    // 不用 WS_EX_TRANSPARENT — 窗口拦截鼠标
    let ex = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TOPMOST;
    let style = WS_POPUP;

    let hwnd = match unsafe {
        CreateWindowExW(
            ex, PCWSTR(class_name_w.as_ptr()),
            PCWSTR(to_wstr("FlashTimeOverlay").as_ptr()),
            style, x, y, w, h,
            Some(null_hwnd()), Some(null_hmenu()), Some(hinst_from_hmodule(hinst)), None,
        )
    } {
        Ok(h) => h,
        Err(e) => { log(&format!("CreateWindowExW FAILED: {}", e)); return None; }
    };
    if hwnd == null_hwnd() { return None; }

    unsafe {
        let _ = SetWindowPos(hwnd, Some(HWND_TOPMOST), x, y, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW);
        // 用 LWA_COLORKEY 实现视觉透明：红色 key 不可见，但窗口仍接收鼠标事件
        let _ = SetLayeredWindowAttributes(hwnd, OVERLAY_COLOR, 0, LWA_COLORKEY);
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        let _ = SetTimer(Some(hwnd), TIMER_TOPMOST, TIMER_INTERVAL, None);
    }
    Some(hwnd)
}

/// 临时隐藏窗口 → mouse_event 模拟点击 → Sleep(50) → 恢复窗口
fn forward_mouse_event(hwnd: HWND, down_flag: MOUSE_EVENT_FLAGS, up_flag: MOUSE_EVENT_FLAGS) {
    unsafe {
        let _ = ShowWindow(hwnd, SW_HIDE);
        mouse_event(down_flag, 0, 0, 0, 0);
        mouse_event(up_flag, 0, 0, 0, 0);
        Sleep(50);
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
    }
}

// ── WndProc ───────────────────────────────────────────────────────────────

extern "system" fn wnd_proc(hwnd: HWND, msg: u32, wparam: WPARAM, lparam: LPARAM) -> LRESULT {
    match msg {
        WM_CLOSE => LRESULT(0), // 拦截

        WM_DESTROY => {
            log("WM_DESTROY — recreating window");
            if let Some(hinst_ptr) = *G_HINST.lock().unwrap() {
                let hinst = HMODULE(hinst_ptr as *mut _);
                let cls = to_wstr("FlashTimeOverlayClass");
                if let Some(new_hwnd) = create_overlay_window(hinst, &cls) {
                    *OVERLAY_HWND.lock().unwrap() = Some(SendHWND(new_hwnd));
                }
            }
            LRESULT(0)
        }

        WM_LBUTTONDOWN => {
            let x = (lparam.0 & 0xFFFF) as i16 as i32;
            let y = ((lparam.0 >> 16) & 0xFFFF) as i16 as i32;
            let mut sp = POINT { x, y };
            let _ = unsafe { ClientToScreen(hwnd, &mut sp) };

            let now = Instant::now();
            let mut is_double = false;
            CLICK_INFO.with(|ci| {
                let mut ci = ci.borrow_mut();
                if let Some(last) = ci.last_time {
                    if now.duration_since(last) < Duration::from_millis(DOUBLE_CLICK_MS)
                        && (sp.x - ci.last_x).abs() < DOUBLE_CLICK_PX
                        && (sp.y - ci.last_y).abs() < DOUBLE_CLICK_PX
                    {
                        ci.last_time = None;
                        is_double = true;
                    } else {
                        ci.last_time = Some(now);
                        ci.last_x = sp.x;
                        ci.last_y = sp.y;
                    }
                } else {
                    ci.last_time = Some(now);
                    ci.last_x = sp.x;
                    ci.last_y = sp.y;
                }
            });

            if is_double {
                // 双击 → emit，取消待转发 timer
                let _ = unsafe { KillTimer(Some(hwnd), TIMER_FORWARD) };
                PENDING.with(|p| { *p.borrow_mut() = None; });
                log("DOUBLE CLICK → emit");
                emit_event("overlay-double-click");
            } else {
                // 第一次单击 → 保存坐标，设置延迟转发 timer
                PENDING.with(|p| {
                    *p.borrow_mut() = Some(PendingClick { x: sp.x, y: sp.y });
                });
                let _ = unsafe { SetTimer(Some(hwnd), TIMER_FORWARD, FORWARD_DELAY, None) };
            }
            LRESULT(0)
        }

        WM_LBUTTONUP => LRESULT(0), // 不转发 — timer 到期后一起转发 down+up

        WM_RBUTTONDOWN => LRESULT(0), // 等右键 up 一起转发
        WM_RBUTTONUP => {
            // 右键 → 立即转发
            log("right click → forward");
            forward_mouse_event(hwnd, MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP);
            LRESULT(0)
        }

        WM_TIMER => {
            let id = wparam.0;
            if id == TIMER_TOPMOST {
                // 刷新 topmost + 可见性
                let (x, y, w, h) = overlay_rect();
                unsafe {
                    let _ = SetWindowPos(hwnd, Some(HWND_TOPMOST), x, y, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW);
                    if !IsWindowVisible(hwnd).as_bool() {
                        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
                    }
                }
            } else if id == TIMER_FORWARD {
                // 延迟转发左键单击
                let _ = unsafe { KillTimer(Some(hwnd), TIMER_FORWARD) };
                let click = PENDING.with(|p| p.borrow_mut().take());
                if let Some(c) = click {
                    log(&format!("forwarding single click at ({}, {})", c.x, c.y));
                    forward_mouse_event(hwnd, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP);
                }
            }
            LRESULT(0)
        }

        _ => unsafe { DefWindowProcW(hwnd, msg, wparam, lparam) },
    }
}

// ── Public API ────────────────────────────────────────────────────────────

pub fn start_overlay(app: AppHandle) {
    set_app_handle(app);
    SHOULD_STOP.store(false, Ordering::Relaxed);
    std::thread::Builder::new()
        .name("flashtime-overlay".into())
        .spawn(|| {
            let hinst: HMODULE = unsafe { GetModuleHandleW(None) }.unwrap_or(null_hmodule());
            *G_HINST.lock().unwrap() = Some(hinst.0 as usize);
            let thread_id = unsafe { GetCurrentThreadId() };
            *OVERLAY_THREAD_ID.lock().unwrap() = Some(thread_id);
            log(&format!("thread_id = {}", thread_id));

            let cls = to_wstr("FlashTimeOverlayClass");
            register_class(hinst, &cls);

            if let Some(hwnd) = create_overlay_window(hinst, &cls) {
                log(&format!("window created, hwnd = {:?}", hwnd));
                *OVERLAY_HWND.lock().unwrap() = Some(SendHWND(hwnd));
            }

            unsafe {
                let mut msg: MSG = std::mem::zeroed();
                loop {
                    let b = GetMessageW(&mut msg, Some(null_hwnd()), 0, 0);
                    if b.0 <= 0 {
                        log(&format!("message loop ended, b.0 = {}", b.0));
                        break;
                    }
                    let _ = TranslateMessage(&msg);
                    let _ = DispatchMessageW(&msg);
                }
            }
            log("thread exiting");
        })
        .unwrap();
}

pub fn stop_overlay() {
    SHOULD_STOP.store(true, Ordering::Relaxed);
    if let Some(tid) = OVERLAY_THREAD_ID.lock().unwrap().take() {
        let _ = unsafe { PostThreadMessageW(tid, WM_QUIT, WPARAM(0), LPARAM(0)) };
    }
    OVERLAY_HWND.lock().unwrap().take();
}

pub fn reposition_overlay() {
    if let Some(SendHWND(hwnd)) = *OVERLAY_HWND.lock().unwrap() {
        let (x, y, w, h) = overlay_rect();
        let _ = unsafe {
            SetWindowPos(hwnd, Some(HWND_TOPMOST), x, y, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW)
        };
    }
}
